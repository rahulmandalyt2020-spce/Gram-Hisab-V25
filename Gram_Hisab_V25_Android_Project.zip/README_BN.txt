GRAM HISAB V25 — ANDROID BUILD PROJECT

এই ZIP-এ Gram Hisab V25 HTML-কে Android WebView app-এর মধ্যে রাখা হয়েছে এবং GitHub Actions APK build workflow যোগ করা হয়েছে।

গুরুত্বপূর্ণ:
- এটি একটি প্রথম Android wrapper/build-ready project; APK build সফল হয়েছে বলে এখনও দাবি করা হচ্ছে না।
- আগে HTML prototype-এ যে ফিচার আছে, wrapper সেগুলোই দেখায়। Android-এর native PDF/CSV sharing, reliable backup/restore, long-term data safety ইত্যাদি আলাদা করে বাস্তব ফোনে যাচাই করতে হবে।
- LocalStorage/WebView data অ্যাপের data clear বা uninstall করলে হারাতে পারে। জরুরি পারিবারিক হিসাবের জন্য আলাদা backup রাখুন।
- Home design/HTML পরিবর্তন করা হয়নি।

GitHub দিয়ে APK build:
1. ZIP extract করুন।
2. GitHub-এ নতুন repository বানান (যেমন Gram-Hisab-V25)।
3. এই ZIP-এর ভিতরের সব ফাইল repository-তে upload/commit করুন।
4. Actions tab খুলুন।
5. “Build Gram Hisab V25 APK” workflow চালু করুন বা main/master-এ push হলে শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
6. সফল হলে workflow run → Artifacts → Gram-Hisab-V25-debug-APK ডাউনলোড করুন।
7. ZIP artifact extract করে app-debug.apk ফোনে নিন ও install করুন।

Application ID: com.rahuldigitallab.gramhisab
Version: 25.0
